#ifndef EDT_H
#define EDT_H
#include <iostream>
#include <string>
#include <list>
#include "semaine.h"

class edt
{
private:
    std::list<Semaine> listSemaines;
public:
    edt();
};

#endif // EDT_H
