#ifndef MAIN_H
#define MAIN_H

typedef enum cours {CM, TD, TP_INFO, TP_ELEC, EXAMEN} cours;

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;

#endif // MAIN_H
