#include "supprimerGroupeWindow.h"
#include <QLabel>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QDebug>

SupprimerGroupeWindow::SupprimerGroupeWindow(QWidget *parent)
    : QMainWindow(parent) {

    resize(600, 300);
    setWindowTitle("Supprimer un groupe d'étudiants");
    setWindowModality(Qt::ApplicationModal);

    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    // Définition du style pour la fenêtre
    this->setStyleSheet(
        "QWidget {"
        "    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, "
        "                stop:0 #ffe5d9, stop:1 #d5b3f1);"
        "} "
        "QLabel {"
        "    color: #5e239d;"
        "    font: 14pt 'Aptos';"
        "    background: transparent;"
        "} "
        "QPushButton {"
        "    color: white;"
        "    font: 14pt 'Aptos';"
        "    padding: 15px 25px;"
        "    border: none;"
        "    border-radius: 25px;"
        "} "
        "QPushButton#deleteButton {"
        "    background-color: #ff6f61;"
        "} "
        "QPushButton#deleteButton:hover {"
        "    background-color: #ff3d33;"
        "} "
        "QPushButton#cancelButton {"
        "    background-color: #7b68ee;"
        "} "
        "QPushButton#cancelButton:hover {"
        "    background-color: #6a5acd;"
        "} "
        "QComboBox {"
        "    font-size: 14px;"
        "    padding: 6px;"
        "    border: 2px solid #5e239d;"
        "    border-radius: 10px;"
        "    background-color: white;"
        "} "
        "QLineEdit {"
        "    font-size: 14px;"
        "    padding: 8px;"
        "    border: 2px solid #5e239d;"
        "    border-radius: 10px;"
        "    background-color: white;"
        "} "
        "QPushButton#okButton {"
        "    background-color: #ff6f61;"
        "} "
        "QPushButton#okButton:hover {"
        "    background-color: #ff3d33;"
        "} "
        );

    // Mise en place du layout principal
    mainLayout = new QVBoxLayout();
    centralWidget->setLayout(mainLayout);

    // Titre de la fenêtre
    QLabel *titleLabel = new QLabel("Supprimer un groupe d'étudiants :", this);
    titleLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(titleLabel);

    formLayout = new QFormLayout();
    groupComboBox = new QComboBox(this);
    formLayout->addRow("Nom du groupe :", groupComboBox);
    mainLayout->addLayout(formLayout);

    // Charger les groupes à partir du fichier CSV
    loadGroupsFromCSV();

    // Layout pour les boutons
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    deleteButton = new QPushButton("Supprimer", this);
    deleteButton->setObjectName("deleteButton");

    cancelButton = new QPushButton("Annuler", this);
    cancelButton->setObjectName("cancelButton");

    buttonLayout->addWidget(cancelButton);
    buttonLayout->addWidget(deleteButton);
    mainLayout->addLayout(buttonLayout);

    // Connexions des signaux
    connect(deleteButton, &QPushButton::clicked, this, &SupprimerGroupeWindow::onDeleteClicked);
    connect(cancelButton, &QPushButton::clicked, this, &SupprimerGroupeWindow::onCancelClicked);
}

SupprimerGroupeWindow::~SupprimerGroupeWindow() {}

void SupprimerGroupeWindow::loadGroupsFromCSV() {
    QFile file(QDir::currentPath() + "/../../CSV/" + "Groupes.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Erreur", "Impossible de lire le fichier Groupes.csv.");
        return;
    }

    QTextStream in(&file);
    bool isFirstLine = true;

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();

        if (isFirstLine) {
            isFirstLine = false;
            continue;
        }

        if (!line.isEmpty()) {
            QStringList fields = line.split(",");
            if (!fields.isEmpty()) {
                groupComboBox->addItem(fields[0]);
            }
        }
    }
    file.close();
}

void SupprimerGroupeWindow::onDeleteClicked() {
    QString selectedGroup = groupComboBox->currentText();

    if (selectedGroup.isEmpty()) {
        QMessageBox msgBox;
        msgBox.setIcon(QMessageBox::Warning);
        msgBox.setText("Aucun groupe sélectionné. Veuillez en choisir un.");
        msgBox.setWindowTitle("Erreur");

        // Styliser le bouton "OK" pour cette fenêtre
        QAbstractButton* okButton = msgBox.button(QMessageBox::Ok);
        QPushButton* pushButtonOk = qobject_cast<QPushButton*>(okButton);
        if (pushButtonOk) {
            pushButtonOk->setObjectName("okButton");
            pushButtonOk->setStyleSheet("background-color: #ff6f61; color: white;");
        }

        msgBox.exec();
        return;
    }

    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Information);
    msgBox.setText(QString("Le groupe '%1' a été supprimé avec succès.").arg(selectedGroup));
    msgBox.setWindowTitle("Succès");

    // Styliser le bouton "OK" pour cette fenêtre
    QAbstractButton* okButton = msgBox.button(QMessageBox::Ok);
    QPushButton* pushButtonOk = qobject_cast<QPushButton*>(okButton);
    if (pushButtonOk) {
        pushButtonOk->setObjectName("okButton");
        pushButtonOk->setStyleSheet("background-color: #ff6f61; color: white;");
    }

    msgBox.exec();
}

void SupprimerGroupeWindow::onCancelClicked() {
    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Information);
    msgBox.setText("Suppression annulée.");
    msgBox.setWindowTitle("Annulé");

    // Styliser le bouton "OK" pour cette fenêtre
    QAbstractButton* okButton = msgBox.button(QMessageBox::Ok);
    QPushButton* pushButtonOk = qobject_cast<QPushButton*>(okButton);
    if (pushButtonOk) {
        pushButtonOk->setObjectName("okButton");
        pushButtonOk->setStyleSheet("background-color: #ff6f61; color: white;");
    }

    msgBox.exec();
    close();
}
