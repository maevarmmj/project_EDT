#include "supprimerEnseignantWindow.h"
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QDebug>

SupprimerEnseignantWindow::SupprimerEnseignantWindow(QWidget *parent)
    : QMainWindow(parent) {

    resize(600, 300);
    setWindowTitle("Supprimer un enseignant");
    setWindowModality(Qt::ApplicationModal);

    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    // Application du style du premier code pour l'aspect graphique
    this->setStyleSheet(
        "QWidget {"
        "    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, "
        "                stop:0 #ffe5d9, stop:1 #d5b3f1);"
        "} "
        "QLabel {"
        "    color: #5e239d;"
        "    font: 14pt 'Aptos';"
        "    background: transparent;"
        "} "
        "QPushButton {"
        "    color: white;"
        "    font: 14pt 'Aptos';"
        "    padding: 15px 25px;"
        "    border: none;"
        "    border-radius: 25px;"
        "} "
        "QPushButton#deleteButton {"
        "    background-color: #ff6f61;"
        "} "
        "QPushButton#deleteButton:hover {"
        "    background-color: #ff3d33;"
        "} "
        "QPushButton#cancelButton {"
        "    background-color: #7b68ee;"
        "} "
        "QPushButton#cancelButton:hover {"
        "    background-color: #6a5acd;"
        "} "
        "QLineEdit {"
        "    font-size: 14px;"
        "    padding: 8px;"
        "    border: 2px solid #5e239d;"
        "    border-radius: 10px;"
        "    background-color: white;"
        "} "
        "QComboBox {"
        "    font-size: 14px;"
        "    padding: 6px;"
        "    border: 2px solid #5e239d;"
        "    border-radius: 10px;"
        "    background-color: white;"
        "}"
        );

    mainLayout = new QVBoxLayout();
    centralWidget->setLayout(mainLayout);

    QLabel *titleLabel = new QLabel("Supprimer un enseignant :", this);
    titleLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(titleLabel);

    formLayout = new QFormLayout();
    nameComboBox = new QComboBox(this);
    prenomComboBox = new QComboBox(this);

    formLayout->addRow("Nom :", nameComboBox);
    formLayout->addRow("Prénom :", prenomComboBox);
    mainLayout->addLayout(formLayout);

    loadTeachersFromCSV();

    connect(nameComboBox, &QComboBox::currentTextChanged, this, &SupprimerEnseignantWindow::updatePrenomComboBox);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    deleteButton = new QPushButton("Supprimer", this);
    deleteButton->setObjectName("deleteButton");

    cancelButton = new QPushButton("Annuler", this);
    cancelButton->setObjectName("cancelButton");

    buttonLayout->addWidget(cancelButton);
    buttonLayout->addWidget(deleteButton);
    mainLayout->addLayout(buttonLayout);

    connect(deleteButton, &QPushButton::clicked, this, &SupprimerEnseignantWindow::onDeleteClicked);
    connect(cancelButton, &QPushButton::clicked, this, &SupprimerEnseignantWindow::onCancelClicked);
}

SupprimerEnseignantWindow::~SupprimerEnseignantWindow() {}

void SupprimerEnseignantWindow::loadTeachersFromCSV() {
    QFile file(QDir::currentPath() + "/../../CSV/" + "Enseignants.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Erreur", "Impossible de lire le fichier Enseignant.csv.");
        return;
    }

    QTextStream in(&file);
    bool isFirstLine = true;

    teacherData.clear();

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();

        if (isFirstLine) {
            isFirstLine = false;
            continue;
        }

        if (!line.isEmpty()) {
            QStringList fields = line.split(",");
            if (fields.size() >= 2) {
                QString nom = fields[0].trimmed();
                QString prenom = fields[1].trimmed();
                teacherData[nom].append(prenom); // Associer le prénom au nom
            }
        }
    }
    file.close();

    nameComboBox->addItem("Sélectionner");
    nameComboBox->addItems(teacherData.keys());
}

void SupprimerEnseignantWindow::updatePrenomComboBox(const QString &selectedName) {
    prenomComboBox->clear();

    if (teacherData.contains(selectedName)) {
        prenomComboBox->addItems(teacherData[selectedName]);
    }
}

void SupprimerEnseignantWindow::onDeleteClicked() {
    QString nom = nameComboBox->currentText();
    QString prenom = prenomComboBox->currentText();

    if (nom.isEmpty() || prenom.isEmpty()) {
        QMessageBox msgBox;
        msgBox.setIcon(QMessageBox::Warning);
        msgBox.setText("Veuillez sélectionner un nom et un prénom.");
        msgBox.setWindowTitle("Erreur");

        QAbstractButton* okButton = msgBox.button(QMessageBox::Ok);
        QPushButton* pushButtonOk = qobject_cast<QPushButton*>(okButton);
        if (pushButtonOk) {
            pushButtonOk->setStyleSheet("background-color: #ff6f61; color: white;");
        }

        msgBox.exec();
        return;
    }

    // Suppression de l'enseignant (affichage d'une information pour l'exemple)
    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Information);
    msgBox.setText(QString("L'enseignant '%1 %2' a été supprimé.").arg(nom, prenom));
    msgBox.setWindowTitle("Succès");

    QAbstractButton* okButton = msgBox.button(QMessageBox::Ok);
    QPushButton* pushButtonOk = qobject_cast<QPushButton*>(okButton);
    if (pushButtonOk) {
        pushButtonOk->setStyleSheet("background-color: #ff6f61; color: white;");
    }

    msgBox.exec();
}

void SupprimerEnseignantWindow::onCancelClicked() {
    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Information);
    msgBox.setText("Suppression annulée.");
    msgBox.setWindowTitle("Annulé");

    QAbstractButton* okButton = msgBox.button(QMessageBox::Ok);
    QPushButton* pushButtonOk = qobject_cast<QPushButton*>(okButton);
    if (pushButtonOk) {
        pushButtonOk->setStyleSheet("background-color: #ff6f61; color: white;");
    }

    msgBox.exec();
    close();
}
