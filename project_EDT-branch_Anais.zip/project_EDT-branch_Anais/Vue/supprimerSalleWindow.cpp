#include "supprimerSalleWindow.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

SupprimerSalleWindow::SupprimerSalleWindow(QWidget *parent) : QWidget(parent) {
    setWindowTitle("Supprimer un numéro de salle");
    resize(400, 200);
    setWindowModality(Qt::ApplicationModal);

    this->setStyleSheet(
        "QWidget {"
        "    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, "
        "                stop:0 #ffe5d9, stop:1 #d5b3f1);"
        "} "
        "QLabel {"
        "    color: #5e239d;"
        "    font: 14pt 'Aptos';"
        "    background: transparent;"
        "} "
        "QPushButton {"
        "    color: white;"
        "    font: 14pt 'Aptos';"
        "    padding: 15px 25px;"
        "    border: none;"
        "    border-radius: 25px;"
        "} "
        "QPushButton#deleteButton {"
        "    background-color: #ff6f61;"
        "} "
        "QPushButton#deleteButton:hover {"
        "    background-color: #ff3d33;"
        "} "
        "QPushButton#cancelButton {"
        "    background-color: #7b68ee;"
        "} "
        "QPushButton#cancelButton:hover {"
        "    background-color: #6a5acd;"
        "} "
        "QLineEdit {"
        "    font-size: 14px;"
        "    padding: 8px;"
        "    border: 2px solid #5e239d;"
        "    border-radius: 10px;"
        "    background-color: white;"
        "} "
        "QComboBox {"
        "    font-size: 14px;"
        "    padding: 6px;"
        "    border: 2px solid #5e239d;"
        "    border-radius: 10px;"
        "    background-color: white;"
        "}"
        );

    QVBoxLayout *mainLayout = new QVBoxLayout();

    QLabel *label = new QLabel("Sélectionnez le numéro de la salle à supprimer :");
    salleComboBox = new QComboBox();

    if (!chargerSallesDepuisCSV()) {
        QMessageBox::warning(this, "Erreur", "Impossible de charger les numéros de salle depuis le fichier Salles.csv.");
    }

    mainLayout->addWidget(label);
    mainLayout->addWidget(salleComboBox);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    QPushButton *annulerButton = new QPushButton("Annuler");
    QPushButton *supprimerButton = new QPushButton("Supprimer");
    annulerButton->setObjectName("cancelButton");
    supprimerButton->setObjectName("deleteButton");
    buttonLayout->addStretch();
    buttonLayout->addWidget(annulerButton);
    buttonLayout->addWidget(supprimerButton);
    buttonLayout->addStretch();
    mainLayout->addLayout(buttonLayout);

    connect(annulerButton, &QPushButton::clicked, this, &SupprimerSalleWindow::annuler);
    connect(supprimerButton, &QPushButton::clicked, this, &SupprimerSalleWindow::supprimer);

    setLayout(mainLayout);
}

bool SupprimerSalleWindow::chargerSallesDepuisCSV() {
    QFile file(QDir::currentPath() + "/../../CSV/" + "Salles.csv");

    if (!file.exists() || !file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream in(&file);
    bool firstLine = true;

    while (!in.atEnd()) {
        QString line = in.readLine();

        if (firstLine) {
            firstLine = false;
            continue;
        }

        QStringList values = line.split(",");
        if (!values.isEmpty()) {
            salleComboBox->addItem(values[0].trimmed());
        }
    }

    file.close();
    return true;
}

void SupprimerSalleWindow::annuler() {
    QMessageBox::information(this,"Annulation", "L'opération est bien annulée");
    close();
}
void SupprimerSalleWindow::supprimer() {
    QString salleNumber = salleComboBox->currentText();
    if (salleNumber.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Le numéro de la salle n'est pas valide.");
        return;
    }

    // Afficher un message de confirmation
    QMessageBox::information(this, "Succès", QString("La salle numéro %1 a bien été supprimée.").arg(salleNumber));

}
